# LARAVEL

1. install xampp php version 8.2 and install composer
2. change .env with your password,port and username db
3. php artisan migrate
4. insert laravel.sql to mysql database articles
5. php artisan serve
6. php artisan update:updatenews
