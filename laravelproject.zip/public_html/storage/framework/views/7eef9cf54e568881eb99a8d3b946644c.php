<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>FunTech Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">
    <meta name="description" content="FunTech: Greek News technology">
    <meta name="author" content="Antonis Tsakiris">
    <meta name="google-adsense-account" content="ca-pub-3274172624172716">
    <meta name="google-site-verification" content="6pg8xiQYyKn3zdyFa1XFXPJYHanhXXLlBI_VdxMDdLw" />
    <meta name="keywords" content="funtechgr,funtech,resume,greek news,Greek News,news,Greek,greek news technology,make resume,makeresume,Make resume,Make Resume,Antonis Tsakiris,Antonis tsakiris,Αντωνη Τσακιρης,Νεα"/>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/basic.css">

</head>
<body class="text-white">
    <header>
        <nav class="navbar navbar-expand-sm navbar-dark bg-dark" style="margin: 0">
            <div class="container-fluid">
                <a class="navbar-brand" href="/">
                    <img src="<?php echo e(asset('images/favicon.png')); ?>" alt="Avatar Logo" style="width:40px;" class="rounded-pill"> 
                </a>
                <span class="navbar-text text-white">FunTech</span>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="mynavbar">
                <ul class="navbar-nav me-auto">
                  <li class="nav-item">
                    <a class="nav-link" href="/">Home</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="https://www.fiverr.com/s/EGzWWy" target="_blank" rel="noopener noreferrer">Fivver</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="https://websiteservice.site" target="_blank" rel="noopener noreferrer">Websiteservice</a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
    </header>

    <?php echo $__env->yieldContent('content'); ?>



    <footer class="text-center text-lg-start bg-dark text-muted w-100" style="margin-top: 6%;">
      <!-- Section: Social media -->
      <section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
        <!-- Left -->
        <div class="me-5 d-none d-lg-block text-white">
          <span>Get connected with us on social networks:</span>
        </div>
        <!-- Left -->
    
        <!-- Right -->
        <div class="text-white">
          <a href="https://www.instagram.com/antonis_tsak500" class="me-4 text-reset" style="text-decoration: none">
            <i class="bi bi-instagram"></i>
          </a>
          <a href="https://www.facebook.com/profile.php?id=100038616900411" class="me-4 text-reset" style="text-decoration: none">
            <i class="bi bi-facebook"></i>
          </a>
        </div>
        <!-- Right -->
      </section>
      <!-- Section: Social media -->
    
      <!-- Section: Links  -->
      <section class="text-white">
        <div class="container text-center text-md-start mt-5">
          <!-- Grid row -->
          <div class="row mt-3">
            <!-- Grid column -->
            <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
              <!-- Content -->
              <h6 class="text-uppercase fw-bold mb-4">
                <i class="fas fa-gem me-3"></i>Αντωνης Τσακιρης
              </h6>
              <p>
                School: <a href="https://drive.google.com/file/d/1m57DqKrvseAU1eExnSJp5hDVAVWBhjji/view" target="_blank" rel="noopener noreferrer" class="text-white">Certificate</a>
              </p>
              <p>
                Greek: <a href="https://drive.google.com/file/d/1BW-YExsBnulANHkWKoKRb8ehZDkZgzwC/view?usp=sharing" target="_blank" rel="noopener noreferrer" class="text-white">CV</a>
              </p>
              <p>
                English: <a href="https://drive.google.com/file/d/1uG6uJMhUPMXkf3wbByz3nXnGXIOkrBhE/view?usp=sharing" target="_blank" rel="noopener noreferrer" class="text-white">CV</a>
              </p>
            </div>
            <!-- Grid column -->
    
            <!-- Grid column -->
            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold mb-4">
                PAGES
              </h6>
              <p>
                <a href="https://www.fiverr.com/s/jNmX1V" class="text-reset" target="_blank" rel="noopener noreferrer">Fiverr</a>
              </p>
              <p>
                <a class="text-reset" href="https://funtechgr.com" target="_blank" rel="noopener noreferrer">Funtechgr</a>
              </p>
            </div>
            <!-- Grid column -->
    
            <!-- Grid column -->
            <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold mb-4">
                Pages
              </h6>
              <p>
                <a href="<?php echo e(route('home')); ?>" class="text-reset">Home</a>
              </p>
              <p>
                <a href="#" class="text-reset">Contact</a>
              </p>
              <p>
                <a href="#" class="text-reset">Pricing</a>
              </p>
            </div>
            <!-- Grid column -->
    
            <!-- Grid column -->
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
              <!-- Links -->
              <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
              <p><i class="fas fa-home me-3"></i> Διεύθυνση: 71201, Ηράκλειο, Ελλάδα (Κατοικία)</p>
              <p>
                <i class="fas fa-envelope me-3"></i>
                antonistt500@gmail.com
              </p>
              <p><i class="fas fa-phone me-3"></i> (+30) 6976814374</p>
            </div>
            <!-- Grid column -->
          </div>
          <!-- Grid row -->
        </div>
      </section>
      <!-- Section: Links  -->
    
    </footer>
    <script src="<?php echo e(URL::asset('bootstrap/css/bootstrap.min.css')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html><?php /**PATH /home/funtreae/funtechgr/resources/views/layouts/layout.blade.php ENDPATH**/ ?>