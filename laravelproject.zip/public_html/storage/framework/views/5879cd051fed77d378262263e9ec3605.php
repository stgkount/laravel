<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row mt-1 w-100" style="margin-left:auto;margin-right:auto;">
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col bg-dark m-1 roundend p-0">
        <img src="<?php echo e($article->imagenews); ?>" class="w-100">
        <div class="p-2 overflow-auto" style="overflow: hidden">
            <p class="text-white"><?php echo e($article->datenews); ?></p>
            <a class="text-white" href="<?php echo e($article->linktosite); ?>" target="_blank" rel="noopener noreferrer">
                <h3><?php echo e($article->acticletitle); ?></h3>
            </a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>


<ul class="pagination justify-content-center mt-5">
    <?php if($articles->previousPageUrl()): ?>
    <li class="page-item"><a class="page-link" href="<?php echo e($articles->previousPageUrl()); ?>" class="prev">Previous</a></li>
    <?php endif; ?>
    <?php for($i = 1; $i <= $totalPages; $i++): ?>
    <li class="page-item"><a class="page-link" href="<?php echo e($articles->url($i)); ?>"><?php echo e($i); ?></a></li>
    <?php endfor; ?>
    <?php if($articles->nextPageUrl()): ?>
       <li class="page-item"><a class="page-link" href="<?php echo e($articles->nextPageUrl()); ?>" class="next">Next</a></li>
    <?php endif; ?>
  </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/funtreae/funtechgr/resources/views/index.blade.php ENDPATH**/ ?>