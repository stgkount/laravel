
<?php $__env->startSection('content'); ?>
<div class="container bg-dark w-75 text-white mt-5 p-2">
    <h1 class="text-center">Contact</h1>
    <form action="<?php echo e(route('contactrequest')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6">
                <label for="fullname">Fullname</label>
                <input type="text" class="form-control" name="fullname">
            </div>
            <div class="col-md-6">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email">
            </div>

        </div>
        <textarea name="text" id="text" class="w-100 mt-3" rows="10" class="form-control"></textarea>
        <input type="submit" value="Send message" class="btn btn-primary">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anton\Desktop\public_html\resources\views/php/contact.blade.php ENDPATH**/ ?>