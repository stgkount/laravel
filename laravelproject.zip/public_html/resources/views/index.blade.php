@extends('layouts.layout')
@section('content')
<div class="container">
<div class="row mt-1 w-100" style="margin-left:auto;margin-right:auto;">
    @foreach($articles as $article)
    <div class="col bg-dark m-1 roundend p-0">
        @if($article->imagenews)
        <img src="{{ $article->imagenews }}" class="w-100" onerror="this.onerror=null;this.src='{{asset('images/error.jpg')}}';">
        <div class="p-2 overflow-auto" style="overflow: hidden;width: 350px" >
            <p class="text-white">{{ $article->datenews }}</p>
            <a class="text-white" href="{{ $article->linktosite }}" target="_blank" rel="noopener noreferrer">
                <h3>{{ $article->acticletitle }}</h3>
            </a>
        </div>
        @endif
    </div>
    @endforeach
</div>
</div>


<ul class="pagination justify-content-center mt-5">
    @if ($articles->previousPageUrl())
    <li class="page-item"><a class="page-link" href="{{ $articles->previousPageUrl() }}" class="prev">Previous</a></li>
    @endif
    @for ($i = 1; $i <= $totalPages; $i++)
    <li class="page-item"><a class="page-link" href="{{ $articles->url($i) }}">{{ $i }}</a></li>
    @endfor
    @if ($articles->nextPageUrl())
       <li class="page-item"><a class="page-link" href="{{ $articles->nextPageUrl() }}" class="next">Next</a></li>
    @endif
  </ul>
@endsection