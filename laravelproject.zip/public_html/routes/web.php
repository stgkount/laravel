<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\index;
use App\Http\Controllers\contanct;
Route::get('/',[index::class, 'home'])->name('home');
Route::get('/contact',[contanct::class, 'contact'])->name('contact');

Route::post('/contactrequest',[contanct::class, 'contactrequest'])->name('contactrequest');