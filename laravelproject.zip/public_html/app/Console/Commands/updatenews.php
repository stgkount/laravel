<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use GuzzleHttp\Client;
use Symfony\Component\DomCrawler\Crawler;
use App\Models\articles;
class updatenews extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update:updatenews';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'update news';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $client = new Client();
        
        // Specify the URL of the webpage you want to scrape
        $url = 'https://iguru.gr';
    
        // Send an HTTP GET request to the URL and get the response
        $response = $client->request('GET', $url);
    
        // Get the HTML content of the response
        $html = $response->getBody()->getContents();
    
        // Create a new Symfony DomCrawler instance and load the HTML content
        $crawler = new Crawler($html);
        
        // Extract data from the webpage using CSS selectors
        $gettile = $crawler->filter('.g1-column')->filter('.g1-collection-items')->filter('.entry-body')->filter('a')->text();
        $linktitle = $crawler->filter('.g1-column')->filter('.g1-collection-items')->filter('.entry-body')->filter('a')->attr('href');
        $getdate = $crawler->filter('.g1-column')->filter('.g1-collection-items')->filter('.entry-body')->filter('time')->text();
        $getimage =  $crawler->filter('.g1-collection-items')->filter('.g1-frame-inner')->filter('.wp-post-image')->attr('src');
        $post = articles::firstOrCreate(
            ['acticletitle' => $gettile],
            ['linktosite' => $linktitle, 'datenews' => $getdate,'imagenews' => $getimage]
        );
        $post->save();
    }
}
