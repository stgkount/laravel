<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\articles;
class index extends Controller
{
    public function home(){
        $articles = articles::orderBy('created_at', 'desc')->paginate(8);
        $currentPage = $articles->currentPage();

        // Get the total number of pages
        $totalPages = $articles->lastPage();
        
        return view('index',['articles' => $articles,'currentPage' => $currentPage,
        'totalPages' => $totalPages,]);
    }
}
