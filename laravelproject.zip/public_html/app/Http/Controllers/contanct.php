<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\contanct as cnt;
class contanct extends Controller
{
    public function contact(){
        return view('php.contact');
    }

    public function contactrequest(Request $request){
        $fullname = $request->post('fullname');
        $email = $request->post('email');
        $text = $request->post('text');

        $post = new cnt;
        $post->fullname = $fullname;
        $post->email = $email;
        $post->text = $text;
        $post->save();
        return redirect()->route('home');
    }
}
